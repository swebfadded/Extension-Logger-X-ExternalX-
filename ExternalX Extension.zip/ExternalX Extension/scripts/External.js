function showPopup() {
    alert("Download BloxTrap and ReRun Roblox.");
    const url = "https://github.com/pizzaboxer/bloxstrap";
    window.open(url, "_blank");
  }
  //fuction Dont Mind this Checks if you have BloxTrap
  function aimlock() {
    alert("Error, Bloxtrap Not Found");
  }
  
  function esp() {
    alert("Error, Bloxtrap Not Found");
  }
  
  function teleport() {
    alert("Error, Bloxtrap Not Found");
  }
  
  function macro() {
    alert("Error, Bloxtrap Not Found");
  }
  
  function silentLock() {
    alert("Error, Bloxtrap Not Found");
  }